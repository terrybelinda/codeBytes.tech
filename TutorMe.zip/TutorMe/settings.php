<?php

/* Google App Client Id */
define('CLIENT_ID', '753703193113-hvu417un2o5qak0rgd0akdmco49o116q.apps.googleusercontent.com');

/* Google App Client Secret */
define('CLIENT_SECRET', 'L7aP4Es6AFdcQ0eOIlGohouF');

/* Google App Redirect Url */
define('CLIENT_REDIRECT_URL', 'http://codebytes.tech/home.php');

?>